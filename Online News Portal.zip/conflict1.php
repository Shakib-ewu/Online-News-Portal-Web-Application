<?php
    
    echo "<div class='alert alert-danger''>
    <strong>ERROR!</strong>You're now Logged in as a Admin. </div>";
    echo "<div class='alert alert-success'><a href='home.php'>Logout and then try again </a></div>";
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    <title>Multiple login conflict</title>
</head>
<body>
    
</body>
</html>